"use client";

import { useAuth } from "@/context/AuthContext";
import { Menu, LogOut, Bell, Check, Trash2, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect, useRef } from "react";
import apiClient from "@/lib/apiClient";

export function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
    const { user, logout } = useAuth();
    const [notifications, setNotifications] = useState<any[]>([]);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const fetchNotifications = async () => {
            try {
                const res = await apiClient.getNotifications();
                if (res?.data) {
                    setNotifications(res.data);
                }
            } catch (err) {
                console.error("Failed to fetch notifications:", err);
            }
        };
        fetchNotifications();
    }, []);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsDropdownOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const unreadCount = notifications.filter(n => !n.is_read).length;

    const handleMarkAsRead = async (id: string) => {
        try {
            await apiClient.markNotificationRead(id);
            setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
        } catch (err) {
            console.error("Failed to mark as read:", err);
        }
    };

    const handleMarkAllAsRead = async () => {
        try {
            await apiClient.markAllNotificationsRead();
            setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
        } catch (err) {
            console.error("Failed to mark all as read:", err);
        }
    };

    const formatDate = (dateString: string) => {
        const d = new Date(dateString);
        return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return (
        <header className="h-20 bg-slate-900/40 backdrop-blur-3xl border border-white/5 shadow-[0_8px_32px_rgba(0,0,0,0.3)] flex items-center justify-between px-6 sticky top-4 z-30 mx-4 mt-4 mb-2 rounded-3xl transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_15px_40px_rgba(14,165,233,0.15)] hover:border-sky-500/30 hover:bg-slate-900/60">
            <div className="flex items-center gap-4">
                <button onClick={onMenuClick} className="md:hidden text-slate-400 hover:text-white transition">
                    <Menu size={28} />
                </button>
                <h2 className="text-2xl font-bold text-white hidden sm:block tracking-tight">Dashboard Overview</h2>
            </div>

            <div className="flex items-center gap-6">
                {/* Notification Bell */}
                <div className="relative" ref={dropdownRef}>
                    <button 
                        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                        className="group text-slate-400 hover:text-sky-400 transition-all duration-300 relative p-2 rounded-full hover:bg-sky-500/10 hover:shadow-[0_0_15px_rgba(14,165,233,0.2)] hover:-translate-y-0.5"
                    >
                        <Bell size={24} className={unreadCount > 0 ? "group-hover:animate-[wiggle_1s_ease-in-out_infinite]" : ""} />
                        {unreadCount > 0 && (
                            <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 border-2 border-slate-950 rounded-full shadow-[0_0_8px_rgba(244,63,94,0.8)] animate-pulse flex items-center justify-center text-[10px] text-white font-bold">
                                {unreadCount}
                            </span>
                        )}
                    </button>

                    {/* Dropdown Menu */}
                    {isDropdownOpen && (
                        <div className="absolute right-0 mt-3 w-80 sm:w-96 bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.5)] overflow-hidden z-50 animate-in slide-in-from-top-2 duration-200">
                            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950/50">
                                <h3 className="font-bold text-white flex items-center gap-2">
                                    <Bell size={16} className="text-sky-400"/> Notifications
                                </h3>
                                {unreadCount > 0 && (
                                    <button onClick={handleMarkAllAsRead} className="text-xs text-sky-400 hover:text-sky-300 transition-colors flex items-center gap-1">
                                        <Check size={14} /> Mark all read
                                    </button>
                                )}
                            </div>
                            <div className="max-h-[400px] overflow-y-auto">
                                {notifications.length === 0 ? (
                                    <div className="p-8 text-center text-slate-500">
                                        <Mail size={32} className="mx-auto mb-3 opacity-20" />
                                        <p>No new notifications</p>
                                    </div>
                                ) : (
                                    notifications.map((notif) => (
                                        <div 
                                            key={notif.id} 
                                            onClick={() => !notif.is_read && handleMarkAsRead(notif.id)}
                                            className={`p-4 border-b border-slate-800/50 transition-colors cursor-pointer hover:bg-slate-800/40 ${notif.is_read ? 'opacity-60 bg-transparent' : 'bg-sky-900/10'}`}
                                        >
                                            <div className="flex justify-between items-start gap-2 mb-1">
                                                <h4 className={`font-semibold text-sm ${notif.is_read ? 'text-slate-300' : 'text-sky-400'}`}>
                                                    {notif.title}
                                                </h4>
                                                {!notif.is_read && <div className="w-2 h-2 rounded-full bg-sky-500 mt-1.5 flex-shrink-0" />}
                                            </div>
                                            <p className="text-xs text-slate-400 line-clamp-2 mb-2 leading-relaxed whitespace-pre-wrap">{notif.message}</p>
                                            <span className="text-[10px] text-slate-500">{formatDate(notif.created_at)}</span>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-3 border-l border-slate-800 pl-6">
                    <div className="hidden text-right md:block">
                        <p className="text-sm font-semibold text-white leading-tight">{user?.full_name || "User"}</p>
                        <p className="text-xs text-sky-400 font-medium">{user?.email}</p>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-white font-bold text-lg shadow-lg border-2 border-slate-700 overflow-hidden relative cursor-pointer transition-all duration-300 hover:scale-110 hover:border-sky-500 hover:shadow-[0_0_20px_rgba(14,165,233,0.5)] group">
                        {user?.profile_picture ? (
                            <img src={user.profile_picture} alt="Avatar" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                        ) : (
                            <div className="w-full h-full bg-gradient-to-tr from-sky-400 to-blue-700 flex items-center justify-center relative overflow-hidden">
                                <div className="absolute inset-0 bg-white/20 translate-y-[100%] group-hover:translate-y-0 transition-transform duration-300 ease-out" />
                                <span className="relative z-10">{user?.full_name?.charAt(0).toUpperCase() || "U"}</span>
                            </div>
                        )}
                    </div>
                    <Button onClick={logout} variant="ghost" size="icon" className="group text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 ml-2 rounded-full h-10 w-10 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_0_15px_rgba(244,63,94,0.2)]">
                        <LogOut size={20} className="group-hover:-translate-x-0.5 transition-transform" />
                    </Button>
                </div>
            </div>
        </header>
    );
}
