"use client";

import React, { memo } from 'react';

function TradingViewWidget({ symbol }: { symbol: string }) {
  const config = {
    autosize: true,
    symbol: symbol,
    interval: "D",
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    enable_publishing: false,
    backgroundColor: "rgba(15, 23, 42, 0.5)",
    gridColor: "rgba(30, 41, 59, 0.5)",
    hide_top_toolbar: false,
    hide_legend: false,
    save_image: false,
    hide_volume: true,
    support_host: "https://www.tradingview.com"
  };

  const src = `https://www.tradingview-widget.com/embed-widget/advanced-chart/?locale=en#${encodeURIComponent(JSON.stringify(config))}`;

  return (
    <div className="tradingview-widget-container" style={{ height: "100%", width: "100%", position: "absolute", inset: 0 }}>
      <iframe
        src={src}
        style={{ width: "100%", height: "100%", border: "none" }}
        allowFullScreen
      ></iframe>
    </div>
  );
}

export default memo(TradingViewWidget);
