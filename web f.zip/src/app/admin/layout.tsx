"use client";

import { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Topbar } from "@/components/dashboard/Topbar";
import { BitcoinBackground } from "@/components/ui/BitcoinBackground";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
    const { user, isInitialized } = useAuth();
    const router = useRouter();
    const pathname = usePathname();
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    
    const isLoginPage = pathname === "/admin/login" || pathname === "/admin/login/";

    useEffect(() => {
        // Only redirect after initialization and if user is set from API (not just localStorage)
        if (!isInitialized || isLoginPage) return;
        if (user === null) {
            router.push("/admin/login");
        }
        // Do not automatically redirect non-admins to /dashboard here, 
        // instead we will show them an access denied screen below
    }, [user, isInitialized, router, isLoginPage]);

    if (isLoginPage) {
        return <div className="bg-slate-950 min-h-screen">{children}</div>;
    }

    if (!isInitialized) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-950">
                <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin shadow-[0_0_15px_rgba(16,185,129,0.5)]"></div>
            </div>
        );
    }

    if (!user || (user.role !== 'admin' && user.role !== 'superadmin')) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 text-center px-4">
                <div className="w-16 h-16 bg-red-500/10 flex items-center justify-center rounded-full mb-4">
                    <span className="text-red-500 text-3xl font-bold">!</span>
                </div>
                <h1 className="text-2xl font-bold text-white mb-2">Access Denied</h1>
                <p className="text-slate-400 mb-6 max-w-md">You do not have administrative privileges to view this page. Please log in with an admin account.</p>
                <div className="flex gap-4">
                    <button onClick={() => router.push("/dashboard")} className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors">
                        Return to Dashboard
                    </button>
                    <button onClick={() => router.push("/admin/login")} className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-colors">
                        Admin Login
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="flex h-screen bg-slate-950 overflow-hidden text-slate-200 relative">
            <BitcoinBackground />
            
            {/* Mobile Overlay */}
            {isMobileOpen && (
                <div
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 md:hidden transition-opacity"
                    onClick={() => setIsMobileOpen(false)}
                />
            )}

            <Sidebar isMobileOpen={isMobileOpen} closeMobile={() => setIsMobileOpen(false)} isAdminView={true} />

            <div className="flex-1 flex flex-col h-full overflow-hidden relative">
                <Topbar onMenuClick={() => setIsMobileOpen(true)} />
                <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-transparent relative z-10">
                    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
                        {children}
                    </div>
                </main>
            </div>
        </div>
    );
}

// Ensure recompile
