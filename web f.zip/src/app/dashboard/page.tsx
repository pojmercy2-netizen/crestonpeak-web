"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { ArrowUpRight, ArrowDownRight, Wallet, Activity, TrendingUp, CreditCard, ChevronRight, Settings } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import TradingViewWidget from "@/components/ui/TradingViewWidget";

const charts = [
    { name: "Bitcoin", symbol: "BINANCE:BTCUSDT" },
    { name: "Ethereum", symbol: "BINANCE:ETHUSDT" },
    { name: "BNB", symbol: "BINANCE:BNBUSDT" },
    { name: "Gold", symbol: "OANDA:XAUUSD" },
    { name: "Tesla", symbol: "NASDAQ:TSLA" },
];

export default function DashboardOverview() {
    const { user } = useAuth();
    const router = useRouter();
    const [wallet, setWallet] = useState<any>(null);
    const [investments, setInvestments] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);



    useEffect(() => {
        const fetchWalletData = async () => {
            try {
                const apiClient = (await import("@/lib/apiClient")).default;
                const [walletResp, investmentsResp] = await Promise.all([
                    apiClient.getWallet(),
                    apiClient.listInvestments(),
                ]);
                setWallet(walletResp.data);
                setInvestments(investmentsResp.data || []);
            } catch (err) {
                console.error("Failed to fetch wallet data:", err);
            } finally {
                setLoading(false);
            }
        };

        if (user) {
            fetchWalletData();
        }
    }, [user]);

    const activeInvestments = investments.filter((i: any) => i.status === "active");
    const activeInvestmentsTotal = activeInvestments.reduce((sum: number, inv: any) => sum + inv.amount, 0);
    // currentBalance removed as per user request to match availableBalance
    const totalProfit = wallet?.total_earned || 0;
    const activePlansCount = activeInvestments.length;

    const totalDeposited = wallet?.total_deposited || 0;
    const totalWithdrawn = wallet?.total_withdrawn || 0;
    const availableBalance = totalDeposited + totalProfit - totalWithdrawn;

    const [activeChart, setActiveChart] = useState(charts[0].symbol);

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-700 fill-mode-both">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-1">
                    <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">Overview</h1>
                    <p className="text-slate-400 text-sm md:text-base">Here's a summary of your account activity.</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                    <Button asChild className="w-full sm:flex-1 md:w-auto bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold transition-all duration-300 transform hover:-translate-y-1 hover:scale-105 shadow-[0_0_15px_rgba(14,165,233,0.4)] hover:shadow-[0_0_30px_rgba(14,165,233,0.7)] h-12 md:h-11 relative overflow-hidden group">
                        <Link href="/dashboard/deposits">
                            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
                            <Wallet className="mr-2 relative z-10" size={18} />
                            <span className="relative z-10">Deposit</span>
                        </Link>
                    </Button>
                    <Button asChild className="w-full sm:flex-1 md:w-auto bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 hover:border-slate-500 transition-all duration-300 transform hover:-translate-y-1 hover:scale-105 shadow-lg hover:shadow-[0_0_20px_rgba(255,255,255,0.1)] font-bold h-12 md:h-11">
                        <Link href="/dashboard/withdrawals">Withdraw</Link>
                    </Button>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-3 gap-6">
                <Card className="group bg-slate-900 border-none shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] ring-1 ring-slate-800 overflow-hidden relative transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(99,102,241,0.2)] hover:ring-indigo-500/50">
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500"><CreditCard size={80} /></div>
                    <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
                        <CardTitle className="text-sm font-medium text-slate-400 group-hover:text-slate-300 transition-colors">Available Balance</CardTitle>
                        <CreditCard className="w-4 h-4 text-indigo-400 group-hover:animate-pulse shadow-indigo-500/50" />
                    </CardHeader>
                    <CardContent className="relative z-10">
                        <div className="text-3xl font-bold text-white tracking-tight">${availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                        <p className="text-xs text-slate-500 mt-2 font-medium">
                            Ready to withdraw or invest
                        </p>
                    </CardContent>
                </Card>

                <Card className="group bg-slate-900 border-none shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] ring-1 ring-slate-800 overflow-hidden relative transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(14,165,233,0.2)] hover:ring-sky-500/50">
                    <div className="absolute inset-0 bg-gradient-to-br from-sky-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 group-hover:-rotate-12 transition-transform duration-500"><Wallet size={80} /></div>
                    <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
                        <CardTitle className="text-sm font-medium text-slate-400 group-hover:text-slate-300 transition-colors">Total Deposit</CardTitle>
                        <Wallet className="w-4 h-4 text-sky-400 group-hover:animate-pulse" />
                    </CardHeader>
                    <CardContent className="relative z-10">
                        <div className="text-3xl font-bold text-white tracking-tight">${totalDeposited.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                        <p className="text-xs text-emerald-400 mt-2 flex items-center gap-1 font-medium">
                            <ArrowUpRight size={14} /> +14.5% from last month
                        </p>
                    </CardContent>
                </Card>



                <Card className="group bg-slate-900 border-none shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] ring-1 ring-slate-800 overflow-hidden relative transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(16,185,129,0.2)] hover:ring-emerald-500/50">
                    <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500"><TrendingUp size={80} /></div>
                    <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
                        <CardTitle className="text-sm font-medium text-slate-400 group-hover:text-slate-300 transition-colors">Total Profit</CardTitle>
                        <TrendingUp className="w-4 h-4 text-emerald-400 group-hover:animate-pulse" />
                    </CardHeader>
                    <CardContent className="relative z-10">
                        <div className="text-3xl font-bold text-emerald-400 tracking-tight">+${totalProfit.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                        <p className="text-xs text-slate-500 mt-2 font-medium">
                            Lifetime earnings
                        </p>
                    </CardContent>
                </Card>
            </div>

            {/* Quick Actions & Recent Transactions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in slide-in-from-bottom-12 fade-in duration-1000 delay-150 fill-mode-both">
                <Card className="lg:col-span-2 group bg-slate-900 border-none ring-1 ring-slate-800 hover:ring-sky-500/30 transition-all duration-500 shadow-xl hover:shadow-[0_0_40px_rgba(14,165,233,0.15)] rounded-2xl overflow-hidden flex flex-col min-h-[400px]">
                    <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800/50 bg-slate-900/50 gap-4">
                        <div>
                            <CardTitle className="text-xl font-bold text-white">Market Charts</CardTitle>
                            <p className="text-sm text-slate-400 mt-1">Real-time trading data.</p>
                        </div>
                        <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-hide">
                            {charts.map(c => (
                                <Button
                                    key={c.symbol}
                                    variant={activeChart === c.symbol ? "default" : "ghost"}
                                    size="sm"
                                    className={`rounded-full transition-all flex-shrink-0 ${activeChart === c.symbol ? 'bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                                    onClick={() => setActiveChart(c.symbol)}
                                >
                                    {c.name}
                                </Button>
                            ))}
                        </div>
                    </CardHeader>
                    <CardContent className="p-0 flex-1 relative min-h-[400px]">
                        <TradingViewWidget symbol={activeChart} />
                    </CardContent>
                </Card>

                <Card className="group bg-slate-900 border-none ring-1 ring-slate-800 hover:ring-indigo-500/30 transition-all duration-500 shadow-xl hover:shadow-[0_0_40px_rgba(99,102,241,0.15)] rounded-2xl p-1">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-xl font-bold text-white group-hover:text-indigo-100 transition-colors">Wallet Info</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-indigo-600 via-blue-700 to-sky-500 p-5 shadow-[0_0_20px_rgba(14,165,233,0.3)] border border-white/20 transition-transform duration-500 transform-gpu hover:scale-[1.03] hover:-translate-y-1 hover:shadow-[0_10px_40px_rgba(14,165,233,0.6)] cursor-pointer">
                            <div className="absolute inset-0 bg-white/5 opacity-0 hover:opacity-100 transition-opacity duration-300" />
                            <div className="absolute top-0 right-0 p-4 opacity-20"><CreditCard size={100} className="transform rotate-12" /></div>
                            <div className="relative z-10 flex justify-between items-start">
                                <div>
                                    <p className="text-white/80 text-sm font-medium uppercase tracking-wider">Current Balance</p>
                                    <p className="text-3xl font-extrabold text-white mt-1 drop-shadow-md">${availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</p>
                                </div>
                                <div className="w-12 h-8 rounded bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center relative overflow-hidden">
                                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent translate-x-[-100%] animate-[shimmer_2s_infinite]" />
                                    <div className="w-8 h-4 rounded-full bg-gradient-to-r from-red-500/80 to-yellow-500/80 blur-[2px]" />
                                </div>
                            </div>
                            <div className="relative z-10 mt-8 flex items-end justify-between">
                                <div>
                                    <p className="text-white/70 text-xs uppercase tracking-widest mb-1">Card Holder</p>
                                    <p className="text-white font-bold uppercase tracking-wide truncate max-w-[150px] drop-shadow-sm">{user?.full_name || "User Name"}</p>
                                </div>
                                <div>
                                    <p className="text-white font-bold tracking-widest text-lg drop-shadow-sm">**** 4289</p>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <Button asChild className="group w-full justify-between bg-slate-800/80 hover:bg-slate-700/80 text-white border border-slate-700 hover:border-sky-500/50 transition-all duration-300 h-12 shadow-md hover:shadow-[0_0_15px_rgba(14,165,233,0.2)]">
                                <Link href="/dashboard/cards">
                                    <span className="flex items-center gap-2"><CreditCard size={18} className="text-sky-400 group-hover:scale-110 transition-transform" /> Manage Cards</span>
                                    <ChevronRight size={18} className="text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                                </Link>
                            </Button>
                            <Button asChild className="group w-full justify-between bg-slate-800/80 hover:bg-slate-700/80 text-white border border-slate-700 hover:border-emerald-500/50 transition-all duration-300 h-12 shadow-md hover:shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                                <Link href="/dashboard/settings">
                                    <span className="flex items-center gap-2"><Settings size={18} className="text-slate-400 group-hover:rotate-90 group-hover:text-emerald-400 transition-all duration-500" /> Account Settings</span>
                                    <ChevronRight size={18} className="text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                                </Link>
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
