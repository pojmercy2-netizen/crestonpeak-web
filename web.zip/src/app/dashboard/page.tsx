"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { ArrowUpRight, ArrowDownRight, Wallet, Activity, TrendingUp, CreditCard, ChevronRight, Settings } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const charts = [
    { name: "Bitcoin", symbol: "BINANCE:BTCUSDT" },
    { name: "Ethereum", symbol: "BINANCE:ETHUSDT" },
    { name: "BNB", symbol: "BINANCE:BNBUSDT" },
    { name: "Gold", symbol: "OANDA:XAUUSD" },
    { name: "Tesla", symbol: "NASDAQ:TSLA" },
];

export default function DashboardOverview() {
    const { user } = useAuth();
    const router = useRouter();
    const [wallet, setWallet] = useState<any>(null);
    const [investments, setInvestments] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);



    useEffect(() => {
        const fetchWalletData = async () => {
            try {
                const apiClient = (await import("@/lib/apiClient")).default;
                const [walletResp, investmentsResp] = await Promise.all([
                    apiClient.getWallet(),
                    apiClient.listInvestments(),
                ]);
                setWallet(walletResp.data);
                setInvestments(investmentsResp.data || []);
            } catch (err) {
                console.error("Failed to fetch wallet data:", err);
            } finally {
                setLoading(false);
            }
        };

        if (user) {
            fetchWalletData();
        }
    }, [user]);

    const activeInvestments = investments.filter((i: any) => i.status === "active");
    const activeInvestmentsTotal = activeInvestments.reduce((sum: number, inv: any) => sum + inv.amount, 0);
    // currentBalance removed as per user request to match availableBalance
    const totalProfit = wallet?.total_earned || 0;
    const activePlansCount = activeInvestments.length;

    const totalDeposited = wallet?.total_deposited || 0;
    const totalWithdrawn = wallet?.total_withdrawn || 0;
    const availableBalance = totalDeposited + totalProfit - totalWithdrawn;

    const [activeChart, setActiveChart] = useState(charts[0].symbol);

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-1">
                    <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">Overview</h1>
                    <p className="text-slate-400 text-sm md:text-base">Here's a summary of your account activity.</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                    <Button asChild className="w-full sm:flex-1 md:w-auto bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold transition-all shadow-[0_0_15px_rgba(14,165,233,0.3)] hover:shadow-[0_0_20px_rgba(14,165,233,0.5)] h-12 md:h-11">
                        <Link href="/dashboard/deposits">
                            <Wallet className="mr-2" size={18} />
                            Deposit
                        </Link>
                    </Button>
                    <Button asChild className="w-full sm:flex-1 md:w-auto bg-slate-200 hover:bg-white text-slate-900 transition-all font-bold h-12 md:h-11">
                        <Link href="/dashboard/withdrawals">Withdraw</Link>
                    </Button>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-3 gap-6">
                <Card className="bg-slate-900 border-none shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] ring-1 ring-slate-800 overflow-hidden relative">
                    <div className="absolute top-0 right-0 p-6 opacity-10"><CreditCard size={80} /></div>
                    <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
                        <CardTitle className="text-sm font-medium text-slate-400">Available Balance</CardTitle>
                        <CreditCard className="w-4 h-4 text-indigo-400" />
                    </CardHeader>
                    <CardContent className="relative z-10">
                        <div className="text-3xl font-bold text-white">${availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                        <p className="text-xs text-slate-500 mt-2 font-medium">
                            Ready to withdraw or invest
                        </p>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900 border-none shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] ring-1 ring-slate-800 overflow-hidden relative">
                    <div className="absolute top-0 right-0 p-6 opacity-10"><Wallet size={80} /></div>
                    <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
                        <CardTitle className="text-sm font-medium text-slate-400">Total Deposit</CardTitle>
                        <Wallet className="w-4 h-4 text-sky-400" />
                    </CardHeader>
                    <CardContent className="relative z-10">
                        <div className="text-3xl font-bold text-white">${totalDeposited.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                        <p className="text-xs text-emerald-400 mt-2 flex items-center gap-1 font-medium">
                            <ArrowUpRight size={14} /> +14.5% from last month
                        </p>
                    </CardContent>
                </Card>



                <Card className="bg-slate-900 border-none shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] ring-1 ring-slate-800 overflow-hidden relative">
                    <div className="absolute top-0 right-0 p-6 opacity-10"><TrendingUp size={80} /></div>
                    <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
                        <CardTitle className="text-sm font-medium text-slate-400">Total Profit</CardTitle>
                        <TrendingUp className="w-4 h-4 text-emerald-400" />
                    </CardHeader>
                    <CardContent className="relative z-10">
                        <div className="text-3xl font-bold text-emerald-400">+${totalProfit.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                        <p className="text-xs text-slate-500 mt-2 font-medium">
                            Lifetime earnings
                        </p>
                    </CardContent>
                </Card>
            </div>

            {/* Quick Actions & Recent Transactions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2 bg-slate-900 border-none ring-1 ring-slate-800 shadow-xl rounded-2xl overflow-hidden flex flex-col min-h-[400px]">
                    <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800/50 bg-slate-900/50 gap-4">
                        <div>
                            <CardTitle className="text-xl font-bold text-white">Market Charts</CardTitle>
                            <p className="text-sm text-slate-400 mt-1">Real-time trading data.</p>
                        </div>
                        <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-hide">
                            {charts.map(c => (
                                <Button
                                    key={c.symbol}
                                    variant={activeChart === c.symbol ? "default" : "ghost"}
                                    size="sm"
                                    className={`rounded-full transition-all flex-shrink-0 ${activeChart === c.symbol ? 'bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                                    onClick={() => setActiveChart(c.symbol)}
                                >
                                    {c.name}
                                </Button>
                            ))}
                        </div>
                    </CardHeader>
                    <CardContent className="p-0 flex-1 relative min-h-[400px]">
                        <iframe
                            src={`https://s.tradingview.com/widgetembed/?frameElementId=tradingview_1&symbol=${encodeURIComponent(activeChart)}&interval=D&hidesidetoolbar=1&symboledit=1&saveimage=1&toolbarbg=f1f3f6&studies=%5B%5D&theme=dark&style=1&timezone=Etc%2FUTC`}
                            className="absolute inset-0 w-full h-full border-0"
                            allowFullScreen
                        ></iframe>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900 border-none ring-1 ring-slate-800 shadow-xl rounded-2xl p-1">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-xl font-bold text-white">Wallet Info</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-indigo-600 via-blue-700 to-sky-500 p-5 shadow-lg border border-white/10">
                            <div className="absolute top-0 right-0 p-4 opacity-20"><CreditCard size={100} /></div>
                            <div className="relative z-10 flex justify-between items-start">
                                <div>
                                    <p className="text-white/70 text-sm font-medium uppercase tracking-wider">Current Balance</p>
                                    <p className="text-3xl font-bold text-white mt-1">${availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</p>
                                </div>
                            </div>
                            <div className="relative z-10 mt-8 flex items-end justify-between">
                                <div>
                                    <p className="text-white/60 text-xs">Card Holder</p>
                                    <p className="text-white font-medium uppercase tracking-wide truncate max-w-[150px]">{user?.full_name || "User Name"}</p>
                                </div>
                                <div>
                                    <p className="text-white font-bold tracking-widest text-lg">**** 4289</p>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <Button className="w-full justify-between bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 h-12">
                                <span className="flex items-center gap-2"><CreditCard size={18} className="text-sky-400" /> Manage Cards</span>
                                <ChevronRight size={18} className="text-slate-400" />
                            </Button>
                            <Button className="w-full justify-between bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 h-12">
                                <span className="flex items-center gap-2"><Settings size={18} className="text-slate-400" /> Account Settings</span>
                                <ChevronRight size={18} className="text-slate-400" />
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
