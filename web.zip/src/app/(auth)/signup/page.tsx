"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/context/AuthContext";

export default function SignupPage() {
    const { register, isLoading, error: authError } = useAuth();
    const router = useRouter();
    const [error, setError] = useState("");

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError("");

        const formData = new FormData(e.currentTarget);
        const password = formData.get("password") as string;
        const confirmPassword = formData.get("confirmPassword") as string;

        if (password !== confirmPassword) {
            setError("Passwords do not match");
            return;
        }

        const phone = formData.get("phone") as string;
        if (!phone) {
            setError("Phone number is required");
            return;
        }

        try {
            await register({
                email: formData.get("email") as string,
                username: formData.get("username") as string,
                full_name: formData.get("fullName") as string,
                phone,
                password,
                confirmPassword,
                referral_code: (formData.get("referralCode") as string) || undefined,
            });

            router.push("/login?registered=true");
        } catch (err: any) {
            setError(err.message || "An error occurred during registration");
        }
    };

    return (
        <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 py-12">
            <Card className="w-full max-w-lg bg-slate-900 border-none shadow-2xl">
                <CardHeader className="text-center pb-2 flex flex-col items-center">
                    <Link href="/" className="flex flex-col items-center gap-2 mb-4 group">
                        <div className="relative w-[80px] h-[80px] sm:w-[100px] sm:h-[100px] transition-transform duration-300 group-hover:scale-110">
                            <img src="/logo.png" alt="Noble Edge ROI Logo" className="w-full h-full object-contain" />
                        </div>
                        <div className="text-white font-extrabold italic text-xl sm:text-2xl tracking-tighter">
                            Noble <span className="text-sky-400">Edge</span> ROI
                        </div>
                    </Link>
                    <CardTitle className="text-2xl sm:text-3xl font-bold text-sky-400 mt-2">Create Account</CardTitle>
                </CardHeader>
                <form onSubmit={handleSubmit}>
                    <CardContent className="space-y-4 pt-4 px-4 sm:px-6">
                        {error && (
                            <div className="p-3 bg-red-500/10 border border-red-500 rounded text-red-500 text-sm">
                                {error}
                            </div>
                        )}
                        {authError && (
                            <div className="p-3 bg-red-500/10 border border-red-500 rounded text-red-500 text-sm">
                                {authError}
                            </div>
                        )}

                        <Input
                            type="text"
                            name="fullName"
                            placeholder="Full Name"
                            required
                            disabled={isLoading}
                            className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                        />
                        <Input
                            type="text"
                            name="username"
                            placeholder="Username"
                            required
                            disabled={isLoading}
                            className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                        />
                        <Input
                            type="email"
                            name="email"
                            placeholder="Email"
                            required
                            disabled={isLoading}
                            className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                        />
                        <Input
                            type="tel"
                            name="phone"
                            placeholder="Phone Number (e.g. +1 434 359 4490)"
                            required
                            disabled={isLoading}
                            className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                        />
                        <Input
                            type="password"
                            name="password"
                            placeholder="Password (min. 8 characters)"
                            required
                            disabled={isLoading}
                            className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                        />
                        <Input
                            type="password"
                            name="confirmPassword"
                            placeholder="Confirm Password"
                            required
                            disabled={isLoading}
                            className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                        />
                        <Input
                            type="text"
                            name="referralCode"
                            placeholder="Referral Code (Optional)"
                            disabled={isLoading}
                            className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                        />

                        <div className="flex items-center space-x-2 pt-2 pb-4">
                            <Checkbox
                                id="terms"
                                name="terms"
                                required
                                disabled={isLoading}
                                className="border-slate-500 data-[state=checked]:bg-sky-400"
                            />
                            <label
                                htmlFor="terms"
                                className="text-sm font-medium leading-none text-slate-300 peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                                I agree to the{" "}
                                <Link href="#" className="text-sky-400 hover:text-sky-300">
                                    Terms &amp; Conditions
                                </Link>
                            </label>
                        </div>

                        <Button
                            disabled={isLoading}
                            type="submit"
                            className="w-full bg-[#050d32] hover:bg-sky-500 text-white hover:text-slate-900 font-bold h-12 text-lg transition-all"
                        >
                            {isLoading ? "Creating..." : "Submit"}
                        </Button>
                    </CardContent>
                </form>
                <CardFooter className="justify-center pt-2 pb-6">
                    <p className="text-slate-400">
                        Already have an account?{" "}
                        <Link href="/login" className="text-sky-400 hover:text-sky-300 font-medium">
                            Login
                        </Link>
                    </p>
                </CardFooter>
            </Card>
        </div>
    );
}
