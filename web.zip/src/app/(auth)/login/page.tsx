"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/context/AuthContext";

function LoginForm() {
    const { login, isLoading, error: authError } = useAuth();
    const router = useRouter();
    const searchParams = useSearchParams();
    const registered = searchParams.get("registered");

    const [error, setError] = useState("");

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError("");

        const formData = new FormData(e.currentTarget);
        const email = formData.get("email") as string;
        const password = formData.get("password") as string;

        try {
            await login(email, password);
            router.push("/dashboard");
        } catch (err: any) {
            setError(err.message || "Invalid credentials");
        }
    };

    return (
        <Card className="w-full max-w-md bg-slate-900 border-none shadow-2xl">
            <CardHeader className="text-center pb-2 flex flex-col items-center">
                <Link href="/" className="flex flex-col items-center gap-2 mb-4 group">
                    <div className="relative w-[80px] h-[80px] sm:w-[100px] sm:h-[100px] transition-transform duration-300 group-hover:scale-110">
                        <img src="/logo.png" alt="Noble Edge ROI Logo" className="w-full h-full object-contain" />
                    </div>
                    <div className="text-white font-extrabold italic text-xl sm:text-2xl tracking-tighter">
                        Noble <span className="text-sky-400">Edge</span> ROI
                    </div>
                </Link>
                <CardTitle className="text-2xl sm:text-3xl font-bold text-sky-400 mt-2">
                    Login
                </CardTitle>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4 pt-4 px-4 sm:px-6">
                    {registered && (
                        <div className="p-3 bg-green-500/10 border border-green-500 rounded text-green-500 text-sm">
                            Account created! Please log in.
                        </div>
                    )}
                    {error && (
                        <div className="p-3 bg-red-500/10 border border-red-500 rounded text-red-500 text-sm">
                            {error}
                        </div>
                    )}
                    {authError && (
                        <div className="p-3 bg-red-500/10 border border-red-500 rounded text-red-500 text-sm">
                            {authError}
                        </div>
                    )}

                    <Input
                        type="email"
                        name="email"
                        placeholder="Email"
                        required
                        disabled={isLoading}
                        className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                    />
                    <Input
                        type="password"
                        name="password"
                        placeholder="Password"
                        required
                        disabled={isLoading}
                        className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-500 h-12 disabled:opacity-50"
                    />
                    <Button
                        disabled={isLoading}
                        type="submit"
                        className="w-full bg-[#050d32] hover:bg-sky-500 text-white hover:text-slate-900 font-bold h-12 text-lg transition-all mt-2"
                    >
                        {isLoading ? "Logging in..." : "Login"}
                    </Button>
                </CardContent>
            </form>
            <CardFooter className="justify-center pt-2 pb-6">
                <p className="text-slate-400">
                    No account?{" "}
                    <Link
                        href="/signup"
                        className="text-sky-400 hover:text-sky-300 font-medium"
                    >
                        Signup
                    </Link>
                </p>
            </CardFooter>
        </Card>
    );
}

export default function LoginPage() {
    return (
        <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
            <Suspense fallback={<div>Loading...</div>}>
                <LoginForm />
            </Suspense>
        </div>
    );
}
