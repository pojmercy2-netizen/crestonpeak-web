const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

interface RequestOptions extends RequestInit {
    headers?: Record<string, string>;
}

async function fetchWithAuth(url: string, options: RequestOptions = {}) {
    const token = typeof window !== "undefined" ? localStorage.getItem("access_token") : null;

    const headers: Record<string, string> = {
        "Content-Type": "application/json",
        ...(options.headers as Record<string, string>),
    };

    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_URL}${url}`, {
        ...options,
        headers,
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || errorData.message || `API Error: ${response.status}`);
    }

    if (response.status === 204) return null;

    return response.json();
}

export const apiClient = {
    get: (url: string, options?: RequestOptions) => fetchWithAuth(url, { ...options, method: "GET" }),
    post: (url: string, data?: any, options?: RequestOptions) => fetchWithAuth(url, { ...options, method: "POST", body: JSON.stringify(data) }),
    put: (url: string, data?: any, options?: RequestOptions) => fetchWithAuth(url, { ...options, method: "PUT", body: JSON.stringify(data) }),
    patch: (url: string, data?: any, options?: RequestOptions) => fetchWithAuth(url, { ...options, method: "PATCH", body: JSON.stringify(data) }),
    delete: (url: string, options?: RequestOptions) => fetchWithAuth(url, { ...options, method: "DELETE" }),

    // Auth
    login: (data: any) => apiClient.post("/auth/login", data),
    register: (data: any) => apiClient.post("/auth/register", data),

    // User wallet
    getWallet: () => apiClient.get("/wallet/"),
    listTransactions: () => apiClient.get("/wallet/transactions"),
    getDepositAddresses: () => apiClient.get("/wallet/deposit/addresses"),
    submitDeposit: (data: any) => apiClient.post("/wallet/deposit", data),
    submitWithdrawal: (data: any) => apiClient.post("/wallet/withdraw", data),

    // Investments
    listInvestments: () => apiClient.get("/investments/"),
    getInvestmentPlans: () => apiClient.get("/investments/plans"),
    createInvestment: (data: any) => apiClient.post("/investments/", data),

    // Admin - users
    listUsers: () => apiClient.get("/admin/users/"),
    banUser: (id: string) => apiClient.patch(`/admin/users/${id}/ban`),
    unbanUser: (id: string) => apiClient.patch(`/admin/users/${id}/unban`),
    getUserWallet: (id: string) => apiClient.get(`/admin/users/${id}/wallet`),
    addDepositToUser: (id: string, amount: number) => apiClient.post(`/admin/users/${id}/add-deposit`, { amount }),
    deductFundsFromUser: (id: string, amount: number) => apiClient.post(`/admin/users/${id}/deduct-funds`, { amount }),
    deductUserProfit: (id: string, amount: number) => apiClient.post(`/admin/users/${id}/deduct-profit`, { amount }),
    editUserProfit: (id: string, total_earned: number) => apiClient.patch(`/admin/users/${id}/edit-profit`, { total_earned }),
    sendEmailToUser: (id: string, subject: string, body: string) => apiClient.post(`/admin/users/${id}/send-email`, { subject, body }),

    // Admin - transactions
    getDashboardStats: () => apiClient.get("/admin/dashboard/"),
    listAllTransactions: (type?: string, status?: string) => {
        const params = new URLSearchParams();
        if (type) params.set("type", type);
        if (status) params.set("status", status);
        const qs = params.toString();
        return apiClient.get(`/admin/transactions/${qs ? "?" + qs : ""}`);
    },
    listDeposits: () => apiClient.get("/admin/transactions/deposits"),
    listWithdrawals: () => apiClient.get("/admin/transactions/withdrawals"),
    approveDeposit: (id: string, usdAmount: number) => apiClient.patch(`/admin/transactions/deposits/${id}/approve?usd_amount=${usdAmount}`),
    rejectDeposit: (id: string, reason: string) => apiClient.patch(`/admin/transactions/deposits/${id}/reject?admin_note=${encodeURIComponent(reason)}`),
    approveWithdrawal: (id: string) => apiClient.patch(`/admin/transactions/withdrawals/${id}/approve`),
    rejectWithdrawal: (id: string, reason: string) => apiClient.patch(`/admin/transactions/withdrawals/${id}/reject?admin_note=${encodeURIComponent(reason)}`),

    // Settings
    getWhatsappNumber: () => apiClient.get("/settings/whatsapp", { cache: "no-store" }),
    updateWhatsappNumber: (value: string) => apiClient.put("/settings/whatsapp", { value }),
    getGlobalDepositAddresses: () => apiClient.get("/settings/deposit-addresses", { cache: "no-store" }),
    updateGlobalDepositAddresses: (data: any) => apiClient.put("/settings/deposit-addresses", data),
    
    // Statistics
    getStats: () => apiClient.get("/stats"),
};

export default apiClient;
