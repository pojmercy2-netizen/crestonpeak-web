import { Button } from "@/components/ui/button";
import { CheckCircle2, Star } from "lucide-react";
import Link from "next/link";

const plans = [
    {
        name: "Starter Plan",
        price: "$100 – $499",
        popular: false,
        features: ["95% – 100% ROI", "7 – 14 Days", "Forex & low-risk crypto trades", "Weekly updates"]
    },
    {
        name: "Standard Plan",
        price: "$500 – $1,999",
        popular: false,
        features: ["95% – 100% ROI", "14 – 30 Days", "Diversified Forex & crypto", "Weekly withdrawals"]
    },
    {
        name: "Professional Plan",
        price: "$2,000 – $9,999",
        popular: true,
        features: ["95% – 100% ROI", "30 Days Terms", "Automated & manual trading", "Priority 24/7 support"]
    },
    {
        name: "VIP Plan",
        price: "$10,000+",
        popular: false,
        features: ["95% – 100% ROI", "30 – 90 Days", "Dedicated account manager", "Premium market access"]
    }
];

export function PricingPlans() {
    return (
        <section id="plan-section" className="relative py-24 px-4 md:px-12 bg-[#020617] overflow-hidden">
            {/* Background Glow Effects */}
            <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none" />
            
            <div className="relative z-10 text-center mb-16">
                <p className="text-sm font-bold tracking-widest text-sky-400 uppercase mb-3">Investment Tiers</p>
                <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Structured Trading Plans</h2>
                <p className="mt-4 text-slate-400 max-w-2xl mx-auto">Choose an investment tier that aligns with your financial goals. Our AI-driven algorithms and expert traders ensure consistent growth.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto relative z-10">
                {plans.map((plan, index) => (
                    <div 
                        key={index} 
                        className={`relative flex flex-col p-8 rounded-3xl transition-all duration-300 transform hover:-translate-y-2
                            ${plan.popular 
                                ? 'bg-gradient-to-b from-blue-900/40 to-slate-900/80 border border-blue-500/50 shadow-[0_0_40px_rgba(59,130,246,0.3)] md:-mt-4 md:mb-4 lg:-mt-8 lg:mb-8' 
                                : 'bg-slate-900/50 backdrop-blur-md border border-white/5 hover:border-white/20 hover:shadow-2xl'
                            }
                        `}
                    >
                        {plan.popular && (
                            <div className="absolute -top-4 inset-x-0 flex justify-center">
                                <span className="flex items-center gap-1 bg-gradient-to-r from-blue-500 to-sky-400 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg shadow-blue-500/30">
                                    <Star className="w-3.5 h-3.5" fill="currentColor" /> Most Popular
                                </span>
                            </div>
                        )}
                        
                        <div className="mb-6">
                            <h4 className="text-xl font-medium text-slate-300 mb-2">{plan.name}</h4>
                            <div className="flex items-baseline gap-1">
                                <span className="text-3xl font-extrabold text-white">{plan.price}</span>
                            </div>
                        </div>

                        <div className="flex-grow">
                            <ul className="space-y-4 mb-8">
                                {plan.features.map((feature, i) => (
                                    <li key={i} className="flex items-start gap-3">
                                        <CheckCircle2 className={`w-5 h-5 shrink-0 ${plan.popular ? 'text-blue-400' : 'text-slate-500'}`} />
                                        <span className="text-slate-300 text-sm leading-tight">{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <Button 
                            asChild
                            className={`w-full py-6 text-base font-bold transition-all
                                ${plan.popular 
                                    ? 'bg-blue-500 hover:bg-blue-400 text-white shadow-[0_0_15px_rgba(59,130,246,0.5)] hover:shadow-[0_0_25px_rgba(59,130,246,0.6)]' 
                                    : 'bg-white/10 hover:bg-white/20 text-white border border-white/5'
                                }
                            `}
                        >
                            <Link href="/login">Select {plan.name.split(' ')[0]}</Link>
                        </Button>
                    </div>
                ))}
            </div>
        </section>
    );
}
