import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2, ShieldCheck, Globe2, TrendingUp, Clock } from "lucide-react";

export function About() {
    const features = [
        { title: "Secure & Transparent", icon: ShieldCheck },
        { title: "Global Market Access", icon: Globe2 },
        { title: "Expert Market Analysis", icon: TrendingUp },
        { title: "24/7 Customer Support", icon: Clock }
    ];

    return (
        <section id="about-section" className="relative about-us py-24 px-4 md:px-16 bg-[#020617] overflow-hidden border-t border-white/5">
            {/* Background elements */}
            <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[100px] pointer-events-none -translate-y-1/2"></div>
            
            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">

                {/* About Text */}
                <div className="space-y-8">
                    <div>
                        <p className="text-sm font-bold tracking-widest text-sky-400 uppercase mb-3 flex items-center gap-2">
                            <span className="w-8 h-[2px] bg-sky-400"></span> About Us
                        </p>
                        <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight">
                            Pioneering the Future of <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-600">Digital Finance</span>
                        </h2>
                        <p className="text-slate-400 text-lg italic mt-3 tracking-wide">Riding the waves of global financial markets.</p>
                    </div>

                    <div className="space-y-4">
                        <p className="text-slate-300 text-lg leading-relaxed">
                            <strong className="text-white">Noble Edge ROI</strong> is a trusted forex and cryptocurrency trading platform
                            dedicated to empowering traders with innovative tools, deep market insights, and
                            reliable investment solutions.
                        </p>

                        <p className="text-slate-300 text-lg leading-relaxed">
                            We combine advanced trading technology with professional market analysis to help
                            traders navigate market volatility and seize profitable opportunities across
                            forex, crypto, indices, and commodities.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
                        {features.map((item, index) => {
                            const Icon = item.icon;
                            return (
                                <div key={index} className="flex items-center gap-4 bg-white/5 border border-white/5 p-4 rounded-xl hover:bg-white/10 transition-colors">
                                    <div className="p-2 bg-blue-500/10 rounded-lg">
                                        <Icon className="text-sky-400 h-5 w-5" />
                                    </div>
                                    <span className="text-slate-200 font-medium">{item.title}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Mission & Vision Cards Collection */}
                <div className="space-y-6">
                    <Card className="bg-slate-900/60 backdrop-blur-xl border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.3)] rounded-3xl p-8 hover:-translate-y-1 transition-transform duration-300">
                        <CardContent className="p-0">
                            <div className="flex items-start gap-6">
                                <div className="text-5xl font-black text-white/5 tracking-tighter shrink-0 mt-1">01</div>
                                <div>
                                    <h3 className="text-2xl font-bold text-white mb-3">Our Mission</h3>
                                    <p className="text-slate-300 text-lg leading-relaxed">
                                        To deliver reliable, innovative, and user-focused trading solutions that help
                                        our clients grow confidently in the global financial markets.
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-blue-900/40 to-slate-900/80 backdrop-blur-xl border border-blue-500/30 shadow-[0_10px_40px_rgba(59,130,246,0.15)] rounded-3xl p-8 hover:-translate-y-1 transition-transform duration-300 transform lg:translate-x-6 xl:translate-x-8">
                        <CardContent className="p-0">
                            <div className="flex items-start gap-6">
                                <div className="text-5xl font-black text-blue-500/20 tracking-tighter shrink-0 mt-1">02</div>
                                <div>
                                    <h3 className="text-2xl font-bold text-sky-400 mb-3">Our Vision</h3>
                                    <p className="text-slate-200 text-lg leading-relaxed">
                                        To become a leading global trading brand recognized for unyielding integrity,
                                        consistent performance, and long-term trader success.
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

            </div>
        </section>
    );
}
