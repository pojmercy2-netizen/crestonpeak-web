export function TradingSessions() {
    return (
        <section id="global-trading-session" className="sessions py-16 px-4 md:px-24 bg-slate-950 text-center">
            <h2 className="text-3xl font-bold text-sky-500 mb-2">Global Trading Sessions</h2>
            <p className="text-slate-300 mb-10 max-w-2xl mx-auto">Forex market operates 24 hours a day across major global sessions.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">

                {/* London Session */}
                <div className="bg-slate-800 p-6 rounded-xl text-left border-l-4 border-green-500 hover:-translate-y-2 hover:shadow-2xl transition-all duration-300">
                    <h3 className="text-xl font-semibold text-white mb-2">London Session</h3>
                    <span className="inline-block text-sky-400 text-sm mb-4">08:00 – 17:00 GMT</span>
                    <p className="text-slate-200 text-sm leading-relaxed">
                        The London session is the most active trading period, accounting for the highest trading volume.
                        Major pairs like EUR/USD and GBP/USD show strong volatility.
                    </p>
                </div>

                {/* New York Session */}
                <div className="bg-slate-800 p-6 rounded-xl text-left border-l-4 border-blue-500 hover:-translate-y-2 hover:shadow-2xl transition-all duration-300">
                    <h3 className="text-xl font-semibold text-white mb-2">New York Session</h3>
                    <span className="inline-block text-sky-400 text-sm mb-4">13:00 – 22:00 GMT</span>
                    <p className="text-slate-200 text-sm leading-relaxed">
                        This session overlaps with London, creating high liquidity and strong price movements,
                        especially for USD pairs.
                    </p>
                </div>

                {/* Asian Session */}
                <div className="bg-slate-800 p-6 rounded-xl text-left border-l-4 border-amber-500 hover:-translate-y-2 hover:shadow-2xl transition-all duration-300">
                    <h3 className="text-xl font-semibold text-white mb-2">Asian Session</h3>
                    <span className="inline-block text-sky-400 text-sm mb-4">00:00 – 09:00 GMT</span>
                    <p className="text-slate-200 text-sm leading-relaxed">
                        The Asian session is generally calmer, suitable for range trading.
                        JPY, AUD, and NZD pairs are most active.
                    </p>
                </div>

                {/* Sydney Session */}
                <div className="bg-slate-800 p-6 rounded-xl text-left border-l-4 border-pink-500 hover:-translate-y-2 hover:shadow-2xl transition-all duration-300">
                    <h3 className="text-xl font-semibold text-white mb-2">Sydney Session</h3>
                    <span className="inline-block text-sky-400 text-sm mb-4">22:00 – 07:00 GMT</span>
                    <p className="text-slate-200 text-sm leading-relaxed">
                        This session opens the trading day and is often less volatile,
                        setting the tone for the Asian market.
                    </p>
                </div>

            </div>
        </section>
    );
}
