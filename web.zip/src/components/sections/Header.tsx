"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

export function Header() {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const { user, logout, isInitialized } = useAuth();

    const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

    return (
        <div className="sticky top-2 z-[100] px-3 md:px-6 max-w-[1300px] mx-auto w-full transition-all duration-300">
            <header className={`bg-slate-900/95 backdrop-blur-md shadow-[0_8px_20px_-10px_rgba(14,165,233,0.4)] border border-sky-500/10 transition-all duration-300 ${isMenuOpen ? "rounded-2xl" : "rounded-full"}`}>
                <div className="container mx-auto flex items-center justify-between py-2 px-5 md:px-7">
                <Link href="/" className="flex items-center gap-1.5 text-white font-extrabold italic text-lg">
                    <div className="relative w-[45px] h-[45px] sm:w-[55px] sm:h-[55px]">
                        <Image src="/logo.png" alt="Noble Edge ROI Logo" fill className="object-contain" priority />
                    </div>
                    <div className="hidden sm:block">Noble <span className="text-blue-500">Edge</span> ROI</div>
                    <div className="sm:hidden text-base">Noble <span className="text-blue-500">Edge</span></div>
                </Link>

                {/* Desktop Nav */}
                <nav className="hidden lg:flex items-center gap-5">
                    <ul className="flex gap-5 text-white font-medium text-[14px]">
                        <li><Link href="/" className="hover:text-blue-400 transition-colors">Home</Link></li>
                        <li><Link href="/#market-section" className="hover:text-blue-400 transition-colors">Markets</Link></li>
                        <li><Link href="/#plan-section" className="hover:text-blue-400 transition-colors">Plans</Link></li>
                        <li><Link href="/#about-section" className="hover:text-blue-400 transition-colors">About</Link></li>
                        <li><Link href="/#faq-sections" className="hover:text-blue-400 transition-colors">FAQ's</Link></li>
                        <li><Link href="/#global-trading-session" className="hover:text-blue-400 transition-colors">Sessions</Link></li>
                        <li><Link href="/#contact-section" className="hover:text-blue-400 transition-colors">Contact</Link></li>
                    </ul>

                    <div className="flex gap-2 ml-2">
                        {!isInitialized ? null : user ? (
                            <div className="flex items-center gap-3">
                                <Button asChild variant="ghost" size="sm" className="text-sky-400 hover:bg-sky-500/20 hover:text-sky-300 rounded-xl font-bold">
                                    <Link href="/dashboard">Dashboard</Link>
                                </Button>
                                <Button onClick={logout} variant="ghost" size="sm" className="text-orange-500 hover:bg-orange-500/10 hover:text-orange-400 rounded-xl font-medium">
                                    Logout
                                </Button>
                            </div>
                        ) : (
                            <>
                                <Button asChild variant="ghost" size="sm" className="text-sky-100 hover:bg-sky-500/20 hover:text-white rounded-xl font-medium transition-transform hover:-translate-y-0.5">
                                    <Link href="/login">Login</Link>
                                </Button>
                                <Button asChild size="sm" className="bg-blue-600 text-white hover:bg-blue-500 rounded-xl font-medium transition-transform hover:-translate-y-0.5 shadow-lg shadow-blue-500/20">
                                    <Link href="/signup">Sign Up</Link>
                                </Button>
                            </>
                        )}
                    </div>
                </nav>

                {/* Mobile Toggle */}
                <button className="lg:hidden text-white p-1 hover:bg-white/10 rounded-lg transition-colors" onClick={toggleMenu}>
                    {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
            </div>

            {/* Mobile Nav */}
            <div className={`lg:hidden overflow-hidden transition-all duration-300 ease-in-out ${isMenuOpen ? "max-h-[600px] opacity-100 p-6" : "max-h-0 opacity-0 p-0"}`}>
                <ul className="flex flex-col gap-4 text-white text-lg font-medium border-t border-white/10 pt-4">
                    <li><Link href="/" className="hover:text-blue-400 block py-1" onClick={toggleMenu}>Home</Link></li>
                    <li><Link href="/#market-section" className="hover:text-blue-400 block py-1" onClick={toggleMenu}>Markets</Link></li>
                    <li><Link href="/#plan-section" className="hover:text-blue-400 block py-1" onClick={toggleMenu}>Plans</Link></li>
                    <li><Link href="/#about-section" className="hover:text-blue-400 block py-1" onClick={toggleMenu}>About</Link></li>
                    <li><Link href="/#faq-sections" className="hover:text-blue-400 block py-1" onClick={toggleMenu}>FAQ's</Link></li>
                    <li><Link href="/#global-trading-session" className="hover:text-blue-400 block py-1" onClick={toggleMenu}>Sessions</Link></li>
                    <li><Link href="/#contact-section" className="hover:text-blue-400 block py-1" onClick={toggleMenu}>Contact</Link></li>
                </ul>
                <div className="flex flex-col gap-3 mt-6 border-t border-white/10 pt-6">
                    {!isInitialized ? null : user ? (
                        <div className="flex flex-col gap-3 w-full">
                            <span className="text-white/70 text-sm font-medium">Welcome, {user.full_name.split(' ')[0]}</span>
                            <Button asChild className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl" onClick={toggleMenu}>
                                <Link href="/dashboard">Dashboard</Link>
                            </Button>
                            <Button onClick={() => { logout(); toggleMenu(); }} variant="outline" className="w-full border-orange-500/50 text-orange-500 hover:bg-orange-500/10 rounded-xl">
                                Logout
                            </Button>
                        </div>
                    ) : (
                        <div className="grid grid-cols-2 gap-3">
                            <Button asChild variant="outline" className="w-full border-white/20 text-white hover:bg-white/10 rounded-xl" onClick={toggleMenu}>
                                <Link href="/login">Login</Link>
                            </Button>
                            <Button asChild className="w-full bg-blue-600 hover:bg-blue-500 text-white rounded-xl" onClick={toggleMenu}>
                                <Link href="/signup">Sign Up</Link>
                            </Button>
                        </div>
                    )}
                </div>
            </div>
        </header>
        </div>
    );
}
