import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
    {
        question: "What is Forex and Crypto trading?",
        answer: "Forex and cryptocurrency trading involve buying and selling currencies or digital assets to make profit from market price movements."
    },
    {
        question: "Is my investment secure?",
        answer: "Yes, we use advanced security measures, encryption, and risk management strategies to protect your funds."
    },
    {
        question: "How do I start trading?",
        answer: "Create an account, verify your details, fund your wallet, and start trading using our easy-to-use platform."
    },
    {
        question: "What is the minimum investment?",
        answer: "The minimum investment depends on the plan you choose. Some plans start as low as $50."
    },
    {
        question: "Can I withdraw my profits anytime?",
        answer: "Yes, withdrawals are available 24/7, subject to verification and processing time."
    }
];

export function FAQ() {
    return (
        <section id="faq-sections" className="faq-section py-20 px-4 max-w-3xl mx-auto">
            <div className="text-center mb-10">
                <h2 className="text-3xl font-bold text-sky-400 mb-4">Frequently Asked Questions</h2>
                <p className="text-sky-400/80">
                    Find answers to common questions about our trading platform.
                </p>
            </div>

            <Accordion type="single" collapsible className="w-full space-y-4">
                {faqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-lg px-6 border-none data-[state=open]:bg-sky-400 data-[state=open]:text-white transition-colors duration-300">
                        <AccordionTrigger className="text-lg font-semibold text-slate-900 hover:no-underline hover:text-sky-500 data-[state=open]:hover:text-white py-6">
                            {faq.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-slate-700 data-[state=open]:text-white pb-6 leading-relaxed text-base">
                            {faq.answer}
                        </AccordionContent>
                    </AccordionItem>
                ))}
            </Accordion>
        </section>
    );
}
