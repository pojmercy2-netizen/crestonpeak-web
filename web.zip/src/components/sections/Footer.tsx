import Link from "next/link";
import Image from "next/image";
import apiClient from "@/lib/apiClient";

export async function Footer() {
    let whatsappNumber = "+1 (434) 359-4490";
    try {
        const res = await apiClient.getWhatsappNumber();
        if (res?.value) {
            whatsappNumber = res.value;
        }
    } catch (e) {
        // Fallback to default on error
    }

    return (
        <footer className="bg-[#0a1a2f] text-white pt-16 pb-6 px-6 font-sans">
            <div className="container mx-auto max-w-6xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 border-b border-white/10 pb-12 mb-6">

                {/* Brand Info */}
                <div className="space-y-4">
                    <Link href="/" className="flex items-center gap-2 text-white font-extrabold italic text-xl sm:text-2xl">
                        <div className="relative w-[50px] h-[50px] sm:w-[80px] sm:h-[80px]">
                            <Image src="/logo.png" alt="Noble Edge ROI Logo" fill className="object-contain" />
                        </div>
                        <div>Noble <span className="text-blue-500">Edge</span> ROI</div>
                    </Link>
                    <p className="text-sm mt-4 text-slate-400">
                        Noble Edge ROI is a global forex and cryptocurrency trading platform
                        offering secure, fast, and transparent trading solutions for investors worldwide.
                    </p>
                </div>

                {/* Quick Links */}
                <div className="space-y-4">
                    <h3 className="text-[#00bfff] text-xl font-bold">Quick Links</h3>
                    <ul className="space-y-3">
                        <li><Link href="#" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">Home</Link></li>
                        <li><Link href="#about-section" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">About Us</Link></li>
                        <li><Link href="#plan-section" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">Trading plan</Link></li>
                        <li><Link href="#faq-sections" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">FAQ</Link></li>
                        <li><Link href="#contact-section" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">Contact</Link></li>
                    </ul>
                </div>

                {/* Trading */}
                <div className="space-y-4">
                    <h3 className="text-[#00bfff] text-xl font-bold">Trading</h3>
                    <ul className="space-y-3">
                        <li><Link href="#" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">Forex Trading</Link></li>
                        <li><Link href="#" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">Crypto Trading</Link></li>
                        <li><Link href="#" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">Investment Plans</Link></li>
                        <li><Link href="#" className="text-[#cccccc] hover:text-[#00bfff] transition-colors text-xs">Market Analysis</Link></li>
                    </ul>
                </div>

                {/* Contact Info */}
                <div className="space-y-4">
                    <h3 className="text-[#00bfff] text-xl font-bold">Contact Us</h3>
                    <div className="text-sm space-y-3 text-slate-400">
                        <p>Email: investment@nobleedgeroi.com</p>
                        <p>Phone: {whatsappNumber}</p>
                        <p>Location: Global</p>
                    </div>
                </div>

            </div>

            <div className="border-t border-sky-500/20 mt-12 py-6 text-center text-sm text-slate-400">
                <p>© 2016 Noble Edge ROI. All Rights Reserved.</p>
            </div>
        </footer>
    );
}
