import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ArrowRight, Activity } from "lucide-react";

export function Hero() {
    return (
        <section className="relative text-center py-20 px-4 md:py-32 border-b border-white/5">
            {/* Standardized Tailwind Video Background */}
            <div className="absolute inset-0 z-0 overflow-hidden">
                <video autoPlay muted loop playsInline className="absolute top-0 left-0 w-full h-full object-cover opacity-50">
                    <source src="/video.mp4" type="video/mp4" />
                </video>
                <div className="absolute inset-0 bg-gradient-to-b from-[#020617]/40 via-[#020617]/60 to-[#020617]"></div>
            </div>

            <div className="relative z-10 max-w-5xl mx-auto mt-[-1rem]">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-semibold tracking-wide mb-8">
                    <Activity className="w-4 h-4" /> Powering the Next Generation of Traders
                </div>
                
                <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-6 leading-tight tracking-tight">
                    Your Gateway to the <br className="hidden md:block" />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-emerald-400">Future of Digital Finance</span>
                </h1>
                
                <p className="text-slate-300 text-base md:text-lg mb-12 max-w-2xl mx-auto leading-relaxed">
                    We provide a seamless crypto trading experience backed by advanced technology and robust security.<br className="hidden md:block" />
                    Whether you’re a beginner or an experienced trader, our platform empowers you to trade confidently in
                    the fast-growing cryptocurrency market.
                </p>

                <form className="bg-[#020617]/60 backdrop-blur-xl border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.5)] p-4 md:p-5 rounded-2xl flex flex-col sm:flex-row justify-center items-stretch sm:items-center gap-4 max-w-3xl mx-auto relative group transition-all hover:border-white/20">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl pointer-events-none" />
                    
                    <select className="px-5 py-3.5 sm:py-4 rounded-xl font-semibold bg-white/5 border border-white/10 text-white cursor-pointer outline-none focus:border-blue-500 transition-colors w-full sm:w-auto">
                        <option className="bg-slate-900">BTC</option>
                        <option className="bg-slate-900">ETH</option>
                        <option className="bg-slate-900">SOL</option>
                        <option className="bg-slate-900">BNB</option>
                        <option className="bg-slate-900">DOGE</option>
                        <option className="bg-slate-900">XRP</option>
                    </select>
                    
                    <input
                        type="number"
                        placeholder="Amount In USD"
                        className="px-5 py-3.5 sm:py-4 rounded-xl font-medium bg-white/5 border border-white/10 text-white outline-none w-full sm:w-auto sm:flex-1 min-w-0 sm:min-w-[150px] md:min-w-[200px] placeholder:text-slate-500 focus:border-blue-500 transition-colors"
                    />
                    
                    <div className="flex gap-3 w-full sm:w-auto">
                        <Button asChild type="button" className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)] font-bold px-6 sm:px-8 py-6 sm:py-7 text-base sm:text-lg rounded-xl transition-all">
                            <Link href="/login">Buy</Link>
                        </Button>
                        <Button asChild type="button" className="flex-1 bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] font-bold px-6 sm:px-8 py-6 sm:py-7 text-base sm:text-lg rounded-xl transition-all">
                            <Link href="/login">Sell</Link>
                        </Button>
                    </div>
                </form>
            </div>
        </section>
    );
}
