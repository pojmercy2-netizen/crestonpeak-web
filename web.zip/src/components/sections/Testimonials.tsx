import { Star, Quote } from "lucide-react";

export function Testimonials() {
    const reviews = [
        {
            name: "Sarah Jenkins",
            role: "Professional Trader",
            image: "https://i.pravatar.cc/150?img=47",
            text: "Noble Edge ROI completely transformed my portfolio. The automated trading systems are incredibly precise, and the withdrawals are instantly processed. Highly recommended.",
            rating: 5,
        },
        {
            name: "Michael Chen",
            role: "Venture Capitalist",
            image: "https://i.pravatar.cc/150?img=11",
            text: "I've been with several luxury investment platforms, but the transparency and security here are unmatched. The dashboard gives me exactly the metrics I need.",
            rating: 5,
        },
        {
            name: "Elena Rodriguez",
            role: "Retail Investor",
            image: "https://i.pravatar.cc/150?img=32",
            text: "As someone relatively new to crypto investments, the 24/7 support team made everything so simple. I've seen steady returns for the past 6 months.",
            rating: 5,
        },
    ];

    return (
        <section className="py-24 px-4 sm:px-6 lg:px-8 bg-slate-900 relative overflow-hidden">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-sky-500/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/4"></div>

            <div className="max-w-7xl mx-auto relative z-10">
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">
                        What Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-emerald-400">Clients Say</span>
                    </h2>
                    <p className="text-slate-400 text-lg max-w-2xl mx-auto">
                        Don't just take our word for it. Read the experiences of our investors from around the globe.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {reviews.map((review, index) => (
                        <div 
                            key={index}
                            className="bg-slate-950/50 backdrop-blur-md border border-slate-800 rounded-3xl p-8 relative group hover:border-slate-700 transition-colors duration-300"
                        >
                            <Quote className="absolute top-6 right-8 w-12 h-12 text-slate-800/50 group-hover:text-sky-500/10 transition-colors" />
                            
                            <div className="flex gap-1 mb-6">
                                {[...Array(review.rating)].map((_, i) => (
                                    <Star key={i} className="w-5 h-5 fill-emerald-400 text-emerald-400" />
                                ))}
                            </div>
                            
                            <p className="text-slate-300 text-lg leading-relaxed mb-8 relative z-10">
                                "{review.text}"
                            </p>
                            
                            <div className="flex items-center gap-4">
                                <img 
                                    src={review.image} 
                                    alt={review.name} 
                                    className="w-12 h-12 rounded-full border-2 border-slate-800"
                                />
                                <div>
                                    <h4 className="text-white font-bold">{review.name}</h4>
                                    <p className="text-slate-500 text-sm">{review.role}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
