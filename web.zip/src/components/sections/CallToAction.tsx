import Link from "next/link";
import { ArrowRight, ShieldCheck } from "lucide-react";

export function CallToAction() {
    return (
        <section className="py-24 px-4 sm:px-6 lg:px-8 bg-slate-950 relative overflow-hidden">
            {/* Background elements */}
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1639762681057-408e52192e55?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-5"></div>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent"></div>
            
            <div className="max-w-5xl mx-auto relative z-10">
                <div className="bg-gradient-to-br from-emerald-900/40 to-sky-900/40 border border-slate-700/50 rounded-[2.5rem] p-8 md:p-16 text-center backdrop-blur-md shadow-2xl relative overflow-hidden">
                    
                    {/* Decorative glowing orb */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-emerald-500/20 rounded-full blur-[100px]"></div>

                    <div className="relative z-10">
                        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/50 border border-slate-700 mb-8">
                            <ShieldCheck className="w-5 h-5 text-emerald-400" />
                            <span className="text-sm font-medium text-slate-300">Regulated & Secure Platform</span>
                        </div>
                        
                        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 tracking-tight">
                            Ready to Transform Your <br className="hidden md:block" />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Financial Future?</span>
                        </h2>
                        
                        <p className="text-slate-300 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
                            Join over 5,000 investors worldwide who trust Noble Edge to grow their wealth through precision AI-driven strategies.
                        </p>
                        
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                            <Link 
                                href="/signup" 
                                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-emerald-500 to-sky-500 hover:from-emerald-400 hover:to-sky-400 text-white font-bold rounded-full transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] flex items-center justify-center gap-2"
                            >
                                Start Investing Now <ArrowRight className="w-5 h-5" />
                            </Link>
                            <Link 
                                href="/login" 
                                className="w-full sm:w-auto px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-full transition-all border border-slate-600 hover:border-slate-500 flex items-center justify-center"
                            >
                                Contact Sales
                            </Link>
                        </div>
                        
                        <p className="text-slate-500 text-sm mt-8">
                            * Capital at risk. Please read our risk disclosure before investing.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
}
