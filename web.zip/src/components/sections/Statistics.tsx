import { Users, Clock, CheckCircle, TrendingUp } from "lucide-react";

export function Statistics() {
    const statsCards = [
        {
            icon: Users,
            label: "Active Users",
            value: "100M",
            suffix: "+",
            color: "from-blue-500 to-blue-600",
            bgColor: "bg-blue-500/10",
        },
        {
            icon: Clock,
            label: "Years in Business",
            value: "9",
            suffix: " years",
            color: "from-emerald-500 to-emerald-600",
            bgColor: "bg-emerald-500/10",
        },
        {
            icon: CheckCircle,
            label: "Completed Projects",
            value: "500M",
            suffix: "+",
            color: "from-purple-500 to-purple-600",
            bgColor: "bg-purple-500/10",
        },
        {
            icon: TrendingUp,
            label: "Assets Under Management",
            value: "90B",
            suffix: "+",
            color: "from-orange-500 to-orange-600",
            bgColor: "bg-orange-500/10",
        },
    ];

    return (
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-950 to-slate-900 relative overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>

            <div className="relative z-10 max-w-7xl mx-auto">
                {/* Section header */}
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight">
                        Our <span className="bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">Achievements</span>
                    </h2>
                    <p className="text-slate-400 text-lg max-w-2xl mx-auto">
                        Join thousands of investors who trust us with their portfolio. Here's what we've accomplished together.
                    </p>
                </div>

                {/* Stats grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {statsCards.map((card, index) => {
                        const Icon = card.icon;
                        return (
                            <div
                                key={index}
                                className="group relative bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 rounded-2xl p-8 hover:border-slate-600 transition-all duration-300 hover:-translate-y-2"
                            >
                                {/* Gradient background on hover */}
                                <div
                                    className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300`}
                                ></div>

                                {/* Icon background */}
                                <div className={`${card.bgColor} w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                                    <Icon className="w-8 h-8 text-emerald-400" />
                                </div>

                                {/* Content */}
                                <div className="relative z-10">
                                    <p className="text-slate-400 text-sm font-medium mb-2">{card.label}</p>
                                    <div className="flex items-baseline gap-1">
                                        <h3 className="text-4xl font-bold text-white">
                                            {card.value}
                                        </h3>
                                        <span className="text-xl text-emerald-400 font-semibold">{card.suffix}</span>
                                    </div>
                                </div>

                                {/* Decorative corner */}
                                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-emerald-500/0 to-emerald-500/10 rounded-bl-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                            </div>
                        );
                    })}
                </div>

                {/* Trust statement */}
                <div className="mt-16 bg-gradient-to-r from-slate-900/50 to-slate-800/50 border border-slate-700/50 rounded-2xl p-8 text-center backdrop-blur-sm">
                    <p className="text-slate-300 text-lg">
                        <span className="font-semibold text-emerald-400">Trusted by investors worldwide</span> with secure, transparent, and reliable investment solutions.
                    </p>
                </div>
            </div>
        </section>
    );
}
