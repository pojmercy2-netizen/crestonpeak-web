"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, WalletCards, ArrowDownToLine, ArrowUpToLine, History, Settings, FileText, ShieldCheck, Users, ListFilter } from "lucide-react";
import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";

const navItems = [
    { name: "Overview", href: "/dashboard", icon: LayoutDashboard },
    { name: "Deposits", href: "/dashboard/deposits", icon: ArrowDownToLine },
    { name: "Withdrawals", href: "/dashboard/withdrawals", icon: ArrowUpToLine },
    { name: "My Plans", href: "/dashboard/plans", icon: FileText },
    { name: "Transactions", href: "/dashboard/transactions", icon: History },
    { name: "Settings", href: "/dashboard/settings", icon: Settings },
];

const adminItems = [
    { name: "Overview", href: "/admin", icon: LayoutDashboard },
    { name: "Manage Users", href: "/admin/users", icon: Users },
    { name: "All Transactions", href: "/admin/transactions", icon: ListFilter },
    { name: "Global Settings", href: "/admin/settings", icon: Settings },
];

export function Sidebar({ isMobileOpen, closeMobile, isAdminView }: { isMobileOpen?: boolean; closeMobile?: () => void; isAdminView?: boolean }) {
    const pathname = usePathname();
    const { user } = useAuth();
    const [whatsappNumber, setWhatsappNumber] = useState("+14343594490");

    useEffect(() => {
        import("@/lib/apiClient").then(({ default: apiClient }) => {
            apiClient.getWhatsappNumber().then(res => {
                if (res?.value) setWhatsappNumber(res.value);
            }).catch(e => console.error("Failed to fetch whatsapp number", e));
        });
    }, []);

    return (
        <aside className={`w-64 bg-slate-900 border-r border-slate-800 flex-shrink-0 flex flex-col h-full transition-transform duration-300 z-40 
            ${isMobileOpen ? 'translate-x-0 absolute inset-y-0 left-0' : '-translate-x-full absolute inset-y-0 left-0 md:relative md:translate-x-0'}`}>
            <div className="p-6 flex items-center justify-between">
                <Link href="/" className="flex items-center gap-2 text-white font-extrabold italic text-xl tracking-tight">
                    <img src="/logo.png" alt="Noble Edge ROI Logo" className="h-12 w-12 object-contain" />
                    <div>Noble <span className="text-sky-500">Edge</span> ROI</div>
                </Link>
                {isMobileOpen && closeMobile && (
                    <button onClick={closeMobile} className="md:hidden text-slate-400 hover:text-white">
                        ✕
                    </button>
                )}
            </div>
            <nav className="flex-1 px-4 space-y-2 overflow-y-auto mt-4">
                {(user?.role !== 'admin' && !isAdminView) ? (
                    navItems.map((item) => {
                        const isActive = pathname === item.href;
                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                onClick={() => { if (isMobileOpen && closeMobile) closeMobile(); }}
                                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium
                                    ${isActive
                                        ? "bg-sky-500/10 text-sky-400 border border-sky-500/20 shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]"
                                        : "text-slate-400 hover:text-white hover:bg-slate-800"}`}
                            >
                                <item.icon size={20} className={isActive ? "text-sky-400" : "text-slate-500"} />
                                {item.name}
                            </Link>
                        );
                    })
                ) : (
                    <>
                        <p className="px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                            <ShieldCheck size={14} /> Admin Tools
                        </p>
                        {adminItems.map((item) => {
                            const isActive = pathname === item.href;
                            return (
                                <Link
                                    key={item.href}
                                    href={item.href}
                                    onClick={() => { if (isMobileOpen && closeMobile) closeMobile(); }}
                                    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium
                                        ${isActive
                                            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]"
                                            : "text-slate-400 hover:text-white hover:bg-slate-800"}`}
                                >
                                    <item.icon size={20} className={isActive ? "text-emerald-400" : "text-slate-500"} />
                                    {item.name}
                                </Link>
                            );
                        })}
                    </>
                )}
            </nav>
            <div className="p-4 border-t border-slate-800">
                <div className="bg-slate-800 p-4 rounded-xl text-center border border-slate-700 shadow-inner">
                    <WalletCards className="mx-auto mb-2 text-sky-500" size={32} />
                    <p className="text-sm font-medium text-white">Need Support?</p>
                    <a href={`https://wa.me/${whatsappNumber.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer" className="text-xs text-sky-400 hover:underline mt-1 block">Contact Help Desk</a>
                </div>
            </div>
        </aside>
    );
}
