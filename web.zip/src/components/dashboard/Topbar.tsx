"use client";

import { useAuth } from "@/context/AuthContext";
import { Menu, LogOut, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
    const { user, logout } = useAuth();

    return (
        <header className="h-20 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-6 sticky top-0 z-30">
            <div className="flex items-center gap-4">
                <button onClick={onMenuClick} className="md:hidden text-slate-400 hover:text-white transition">
                    <Menu size={28} />
                </button>
                <h2 className="text-2xl font-bold text-white hidden sm:block tracking-tight">Dashboard Overview</h2>
            </div>

            <div className="flex items-center gap-6">
                <button className="text-slate-400 hover:text-sky-400 transition relative">
                    <Bell size={24} />
                    <span className="absolute top-0 right-1 w-2.5 h-2.5 bg-rose-500 border-2 border-slate-950 rounded-full"></span>
                </button>

                <div className="flex items-center gap-3 border-l border-slate-800 pl-6">
                    <div className="hidden text-right md:block">
                        <p className="text-sm font-semibold text-white leading-tight">{user?.full_name || "User"}</p>
                        <p className="text-xs text-sky-400 font-medium">{user?.email}</p>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-white font-bold text-lg shadow-lg border-2 border-slate-700 overflow-hidden relative">
                        {user?.profile_picture ? (
                            <img src={user.profile_picture} alt="Avatar" className="w-full h-full object-cover" />
                        ) : (
                            <div className="w-full h-full bg-gradient-to-tr from-sky-400 to-blue-700 flex items-center justify-center">
                                {user?.full_name?.charAt(0).toUpperCase() || "U"}
                            </div>
                        )}
                    </div>
                    <Button onClick={logout} variant="ghost" size="icon" className="text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 ml-2 rounded-full h-10 w-10">
                        <LogOut size={20} />
                    </Button>
                </div>
            </div>
        </header>
    );
}
